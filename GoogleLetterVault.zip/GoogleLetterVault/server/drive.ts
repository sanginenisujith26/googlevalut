import { google } from "googleapis";

export const createLetterInDrive = async (
  accessToken: string,
  title: string,
  content: string
): Promise<string> => {
  try {
    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: accessToken });

    const drive = google.drive({ version: "v3", auth });

    // Format content as HTML for Google Docs
    const htmlContent = content;

    // Check if 'LetterDrive' folder exists, create if not
    let folderId = await getFolderIdByName(drive, "LetterDrive");
    if (!folderId) {
      folderId = await createFolder(drive, "LetterDrive");
    }

    // Create a text file in Google Drive
    const response = await drive.files.create({
      requestBody: {
        name: title,
        mimeType: "application/vnd.google-apps.document",
        parents: folderId ? [folderId] : undefined,
      },
      media: {
        mimeType: "text/html",
        body: htmlContent,
      },
    });

    if (!response.data.id) {
      throw new Error("Failed to create file in Google Drive");
    }

    return response.data.id;
  } catch (error) {
    console.error("Error creating file in Google Drive:", error);
    throw error;
  }
};

const getFolderIdByName = async (drive: any, folderName: string): Promise<string | null> => {
  try {
    const response = await drive.files.list({
      q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}' and trashed=false`,
      fields: "files(id, name)",
    });

    const folders = response.data.files;
    if (folders && folders.length > 0) {
      return folders[0].id;
    }
    return null;
  } catch (error) {
    console.error("Error finding folder:", error);
    return null;
  }
};

const createFolder = async (drive: any, folderName: string): Promise<string> => {
  try {
    const response = await drive.files.create({
      requestBody: {
        name: folderName,
        mimeType: "application/vnd.google-apps.folder",
      },
      fields: "id",
    });

    return response.data.id;
  } catch (error) {
    console.error("Error creating folder:", error);
    throw error;
  }
};
