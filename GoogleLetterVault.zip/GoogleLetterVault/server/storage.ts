import { users, type User, type InsertUser, letters, type Letter, type InsertLetter } from "@shared/schema";
import { verifyGoogleToken } from "./auth";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyGoogleToken(token: string): Promise<User>;
  getLetter(id: number): Promise<Letter | undefined>;
  getLettersByUserId(userId: number): Promise<Letter[]>;
  createLetter(letter: InsertLetter): Promise<Letter>;
  updateLetter(id: number, updates: Partial<Letter>): Promise<Letter>;
  updateLetterGoogleFileId(id: number, googleFileId: string): Promise<Letter>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private letters: Map<number, Letter>;
  private userId: number;
  private letterId: number;

  constructor() {
    this.users = new Map();
    this.letters = new Map();
    this.userId = 1;
    this.letterId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.googleId === googleId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    // Ensure photoUrl and refreshToken are not undefined
    const safeInsertUser = {
      ...insertUser,
      photoUrl: insertUser.photoUrl || null,
      refreshToken: insertUser.refreshToken || null
    };
    
    const user: User = { ...safeInsertUser, id };
    this.users.set(id, user);
    return user;
  }

  async verifyGoogleToken(token: string): Promise<User> {
    const googleUserData = await verifyGoogleToken(token);
    
    let user = await this.getUserByGoogleId(googleUserData.googleId);
    
    if (!user) {
      user = await this.createUser({
        username: googleUserData.email.split('@')[0],
        googleId: googleUserData.googleId,
        email: googleUserData.email,
        displayName: googleUserData.displayName,
        photoUrl: googleUserData.photoUrl || null,
        accessToken: token,
        refreshToken: null,
      });
    } else {
      // Update access token
      user.accessToken = token;
      this.users.set(user.id, user);
    }
    
    return user;
  }

  async getLetter(id: number): Promise<Letter | undefined> {
    return this.letters.get(id);
  }

  async getLettersByUserId(userId: number): Promise<Letter[]> {
    return Array.from(this.letters.values()).filter(
      (letter) => letter.userId === userId,
    );
  }

  async createLetter(insertLetter: InsertLetter): Promise<Letter> {
    const id = this.letterId++;
    const now = new Date();
    const letter: Letter = {
      ...insertLetter,
      id,
      createdAt: now,
      updatedAt: now,
      googleFileId: null
    };
    this.letters.set(id, letter);
    return letter;
  }

  async updateLetter(id: number, updates: Partial<Letter>): Promise<Letter> {
    const letter = await this.getLetter(id);
    if (!letter) {
      throw new Error(`Letter with id ${id} not found`);
    }

    const updatedLetter: Letter = {
      ...letter,
      ...updates,
      updatedAt: new Date(),
    };

    this.letters.set(id, updatedLetter);
    return updatedLetter;
  }

  async updateLetterGoogleFileId(id: number, googleFileId: string): Promise<Letter> {
    return this.updateLetter(id, { googleFileId });
  }
}

export const storage = new MemStorage();
