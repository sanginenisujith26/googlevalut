import type { Express } from "express";
import passport from "passport";
import { OAuth2Client } from "google-auth-library";
import { storage } from "./storage";

export const googleAuth = (app: Express): void => {
  // Initialize passport
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error, null);
    }
  });
};

export const verifyGoogleToken = async (token: string): Promise<any> => {
  try {
    console.log("GOOGLE_CLIENT_ID:", process.env.GOOGLE_CLIENT_ID);
    console.log("Verifying token length:", token.length);

    const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    
    const payload = ticket.getPayload();
    if (!payload) {
      throw new Error("Invalid token payload");
    }
    
    console.log("Token verification successful for:", payload.email);
    
    return {
      googleId: payload.sub,
      email: payload.email,
      displayName: payload.name,
      photoUrl: payload.picture,
    };
  } catch (error) {
    console.error("Error verifying Google token:", error);
    console.error("Error details:", error instanceof Error ? error.message : String(error));
    throw error;
  }
};
