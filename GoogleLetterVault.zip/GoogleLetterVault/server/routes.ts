import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import passport from "passport";
import session from "express-session";
import { googleAuth } from "./auth";
import { createLetterInDrive } from "./drive";
import { z } from "zod";
import { insertLetterSchema, User } from "@shared/schema";
import memorystore from "memorystore";

// Extend the Express.Session interface to include our user property
declare module 'express-session' {
  interface SessionData {
    user: User;
  }
}

const MemoryStore = memorystore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "letter-drive-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 },
      store: new MemoryStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Set up Google authentication
  googleAuth(app);

  // API routes
  // Authentication routes
  app.post("/api/auth/google", async (req: Request, res: Response) => {
    try {
      console.log("Received auth request body:", req.body);
      const { credential } = req.body;
      if (!credential) {
        console.log("No credential provided in request body");
        return res.status(400).json({ error: "No credential provided" });
      }

      console.log("Processing Google authentication with credential");
      
      // Verify the credential and get user info
      const userData = await storage.verifyGoogleToken(credential);
      if (!userData) {
        console.log("Invalid credential or verification failed");
        return res.status(401).json({ error: "Invalid credential" });
      }

      console.log("User authenticated successfully:", userData.email);
      
      // Store user data in session
      req.session.user = userData;
      
      // Save session
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ error: "Failed to save session" });
        }
        console.log("Session saved successfully");
        return res.status(200).json(userData);
      });
    } catch (error) {
      console.error("Google auth error:", error);
      return res.status(500).json({ error: "Authentication failed" });
    }
  });

  app.get("/api/auth/user", (req: Request, res: Response) => {
    if (req.session.user) {
      return res.status(200).json(req.session.user);
    }
    return res.status(401).json({ error: "Not authenticated" });
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Letter routes
  app.get("/api/letters", async (req: Request, res: Response) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const letters = await storage.getLettersByUserId(req.session.user.id);
      return res.status(200).json(letters);
    } catch (error) {
      console.error("Error getting letters:", error);
      return res.status(500).json({ error: "Failed to get letters" });
    }
  });

  app.get("/api/letters/:id", async (req: Request, res: Response) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const letterId = parseInt(req.params.id);
      if (isNaN(letterId)) {
        return res.status(400).json({ error: "Invalid letter ID" });
      }

      const letter = await storage.getLetter(letterId);
      if (!letter) {
        return res.status(404).json({ error: "Letter not found" });
      }

      if (letter.userId !== req.session.user.id) {
        return res.status(403).json({ error: "Not authorized to access this letter" });
      }

      return res.status(200).json(letter);
    } catch (error) {
      console.error("Error getting letter:", error);
      return res.status(500).json({ error: "Failed to get letter" });
    }
  });

  app.post("/api/letters", async (req: Request, res: Response) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const letterData = insertLetterSchema.parse({
        ...req.body,
        userId: req.session.user.id,
      });

      const letter = await storage.createLetter(letterData);
      return res.status(201).json(letter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid letter data", details: error.errors });
      }
      console.error("Error creating letter:", error);
      return res.status(500).json({ error: "Failed to create letter" });
    }
  });

  app.patch("/api/letters/:id", async (req: Request, res: Response) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const letterId = parseInt(req.params.id);
      if (isNaN(letterId)) {
        return res.status(400).json({ error: "Invalid letter ID" });
      }

      const letter = await storage.getLetter(letterId);
      if (!letter) {
        return res.status(404).json({ error: "Letter not found" });
      }

      if (letter.userId !== req.session.user.id) {
        return res.status(403).json({ error: "Not authorized to update this letter" });
      }

      const updateData = {
        title: req.body.title || letter.title,
        content: req.body.content || letter.content,
      };

      const updatedLetter = await storage.updateLetter(letterId, updateData);
      return res.status(200).json(updatedLetter);
    } catch (error) {
      console.error("Error updating letter:", error);
      return res.status(500).json({ error: "Failed to update letter" });
    }
  });

  // Google Drive API routes
  app.post("/api/drive/save", async (req: Request, res: Response) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const { letterId } = req.body;
      if (!letterId) {
        return res.status(400).json({ error: "Letter ID is required" });
      }

      const letter = await storage.getLetter(letterId);
      if (!letter) {
        return res.status(404).json({ error: "Letter not found" });
      }

      if (letter.userId !== req.session.user.id) {
        return res.status(403).json({ error: "Not authorized to save this letter" });
      }

      const googleFileId = await createLetterInDrive(
        req.session.user.accessToken,
        letter.title,
        letter.content
      );

      const updatedLetter = await storage.updateLetterGoogleFileId(letterId, googleFileId);
      return res.status(200).json(updatedLetter);
    } catch (error) {
      console.error("Error saving to Drive:", error);
      return res.status(500).json({ error: "Failed to save letter to Google Drive" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
