import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useLetters } from "@/context/LetterContext";
import { getContentFromEditor, setContentInEditor } from "@/lib/editor";
import Sidebar from "@/components/Sidebar";
import MobileSidebar from "@/components/MobileSidebar";
import EditorToolbar from "@/components/EditorToolbar";

export default function Editor() {
  const { isAuthenticated, isLoading } = useAuth();
  const { currentLetter, saveLetter, saveToDrive, createLetter } = useLetters();
  const [, setLocation] = useLocation();
  const [title, setTitle] = useState<string>("");
  const [showMobileSidebar, setShowMobileSidebar] = useState<boolean>(false);
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Redirect if not authenticated
    if (!isAuthenticated && !isLoading) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  useEffect(() => {
    // Update editor content and title when current letter changes
    if (currentLetter) {
      setTitle(currentLetter.title);
      setContentInEditor(editorRef, currentLetter.content);
      
      // Calculate last saved time
      const lastEditTime = new Date(currentLetter.updatedAt);
      const now = new Date();
      const diffInMinutes = Math.floor((now.getTime() - lastEditTime.getTime()) / (1000 * 60));
      
      if (diffInMinutes < 1) {
        setLastSaved("Just now");
      } else if (diffInMinutes < 60) {
        setLastSaved(`${diffInMinutes} ${diffInMinutes === 1 ? "minute" : "minutes"} ago`);
      } else {
        const diffInHours = Math.floor(diffInMinutes / 60);
        if (diffInHours < 24) {
          setLastSaved(`${diffInHours} ${diffInHours === 1 ? "hour" : "hours"} ago`);
        } else {
          const diffInDays = Math.floor(diffInHours / 24);
          setLastSaved(`${diffInDays} ${diffInDays === 1 ? "day" : "days"} ago`);
        }
      }
    }
  }, [currentLetter]);

  // Setup auto-save
  useEffect(() => {
    const autoSave = () => {
      if (currentLetter && editorRef.current) {
        const content = getContentFromEditor(editorRef);
        if (content !== currentLetter.content || title !== currentLetter.title) {
          saveLetter(title, content);
          setLastSaved("Just now");
        }
      }
    };

    // Clear existing timer on cleanup
    return () => {
      if (saveTimerRef.current) {
        clearInterval(saveTimerRef.current);
      }
    };
  }, [currentLetter, title, saveLetter]);

  const handleSave = async () => {
    if (!currentLetter) {
      if (title && editorRef.current) {
        const content = getContentFromEditor(editorRef);
        await createLetter(title, content);
      }
    } else {
      if (editorRef.current) {
        const content = getContentFromEditor(editorRef);
        await saveLetter(title, content);
      }
    }
  };

  const handleSaveToDrive = async () => {
    if (currentLetter) {
      await handleSave(); // First save locally
      await saveToDrive(); // Then save to Drive
    }
  };

  const handleNewLetter = async () => {
    setTitle("Untitled Letter");
    setContentInEditor(editorRef, "");
    await createLetter("Untitled Letter", "");
  };

  const toggleMobileSidebar = () => {
    setShowMobileSidebar(!showMobileSidebar);
  };

  if (!isAuthenticated && !isLoading) {
    return null; // Will redirect in the useEffect
  }

  return (
    <>
      <Sidebar onNewLetter={handleNewLetter} />
      
      {/* Mobile Navigation */}
      <div className="md:hidden bg-white border-b border-neutral-200 p-2 flex justify-between items-center">
        <button 
          className="p-2 rounded-md hover:bg-neutral-100"
          onClick={toggleMobileSidebar}
        >
          <span className="material-icons">menu</span>
        </button>
        
        <button 
          className="bg-[#4285F4] text-white py-1 px-3 rounded-md text-sm flex items-center hover:bg-blue-600"
          onClick={handleNewLetter}
        >
          <span className="material-icons text-sm mr-1">add</span>
          New
        </button>
      </div>
      
      {/* Editor Container */}
      <div className="flex-1 flex flex-col bg-white overflow-hidden">
        <EditorToolbar 
          title={title}
          setTitle={setTitle}
          onSave={handleSave}
          lastSaved={lastSaved}
          editorRef={editorRef}
        />
        
        <div className="flex-1 overflow-auto p-8 bg-white">
          <div className="max-w-3xl mx-auto">
            <div 
              ref={editorRef}
              contentEditable={true}
              className="outline-none min-h-full letter-content"
              onBlur={() => {
                if (currentLetter && editorRef.current) {
                  const content = getContentFromEditor(editorRef);
                  if (content !== currentLetter.content || title !== currentLetter.title) {
                    handleSave();
                  }
                }
              }}
            />
          </div>
        </div>
      </div>
      
      {/* Mobile Sidebar */}
      {showMobileSidebar && (
        <MobileSidebar 
          onClose={() => setShowMobileSidebar(false)}
          onNewLetter={handleNewLetter}
        />
      )}
    </>
  );
}
