import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { initGoogleAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

export default function AuthScreen() {
  const { isAuthenticated, login, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      console.log("User is authenticated, redirecting to editor");
      setLocation("/editor");
    } else if (!isLoading) {
      console.log("Initializing Google Auth");
      initGoogleAuth(async (response) => {
        try {
          console.log("Received Google auth response");
          console.log("Sending credential to server");
          const res = await apiRequest(
            "POST", 
            "/api/auth/google", 
            { credential: response.credential }
          );
          
          const userData = await res.json();
          console.log("Authentication successful, user data:", userData);
          login(userData);
          setLocation("/editor");
        } catch (error) {
          console.error("Authentication failed:", error);
        }
      });
    }
  }, [isAuthenticated, isLoading, login, setLocation]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-10">
      <div className="max-w-md w-full text-center space-y-8">
        <div>
          <svg className="w-20 h-20 mx-auto text-[#4285F4]" fill="currentColor" viewBox="0 0 24 24">
            <path d="M21.17,2.06A13.1,13.1,0,0,0,19,1.87a12.94,12.94,0,0,0-7,2.05,12.94,12.94,0,0,0-7-2,13.1,13.1,0,0,0-2.17.19A1,1,0,0,0,2,3.17V21a1,1,0,0,0,1.08,1,10.9,10.9,0,0,1,1.88-.17,11.07,11.07,0,0,1,7,2.33,11.18,11.18,0,0,1,7-2.33,10.9,10.9,0,0,1,1.88.17A1,1,0,0,0,22,21V3.17A1,1,0,0,0,21.17,2.06ZM20,19.6a9.08,9.08,0,0,0-8,2.19V5.88A10.93,10.93,0,0,1,18.53,4,9.44,9.44,0,0,1,20,4.09Z" />
          </svg>
          <h2 className="mt-6 text-3xl font-bold font-poppins text-neutral-800">Welcome to LetterDrive</h2>
          <p className="mt-2 text-neutral-600">Create, edit, and save letters directly to your Google Drive</p>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6 text-left">
          <h3 className="text-xl font-medium text-neutral-800 mb-4">Get Started</h3>
          <ul className="space-y-3 mb-6">
            <li className="flex items-start">
              <span className="material-icons text-[#34A853] mr-2">check_circle</span>
              <span>Create and edit text-based letters</span>
            </li>
            <li className="flex items-start">
              <span className="material-icons text-[#34A853] mr-2">check_circle</span>
              <span>Format your content with simple styling options</span>
            </li>
            <li className="flex items-start">
              <span className="material-icons text-[#34A853] mr-2">check_circle</span>
              <span>Save your letters directly to Google Drive</span>
            </li>
            <li className="flex items-start">
              <span className="material-icons text-[#34A853] mr-2">check_circle</span>
              <span>Access your letters from anywhere</span>
            </li>
          </ul>
          
          <div id="googleSignInButton" className="flex justify-center"></div>
        </div>
        
        <p className="text-sm text-neutral-500">By signing in, you agree to our <a href="#" className="text-[#4285F4] hover:underline">Terms of Service</a> and <a href="#" className="text-[#4285F4] hover:underline">Privacy Policy</a>.</p>
      </div>
    </div>
  );
}
