import React from "react";
import { useLetters } from "@/context/LetterContext";
import { formatDistanceToNow } from "date-fns";

interface MobileSidebarProps {
  onClose: () => void;
  onNewLetter: () => Promise<void>;
}

export default function MobileSidebar({ onClose, onNewLetter }: MobileSidebarProps) {
  const { letters, fetchLetter, isLoading } = useLetters();

  const handleLetterSelect = async (id: number) => {
    await fetchLetter(id);
    onClose();
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (e) {
      return "Unknown date";
    }
  };

  return (
    <div className="fixed inset-0 z-50">
      <div 
        className="absolute inset-0 bg-black bg-opacity-50"
        onClick={onClose}
      ></div>
      <div className="absolute inset-y-0 left-0 w-64 bg-white shadow-lg">
        <div className="flex justify-between items-center p-4 border-b border-neutral-200">
          <h2 className="font-medium">My Letters</h2>
          <button 
            className="p-1.5 rounded hover:bg-neutral-100"
            onClick={onClose}
          >
            <span className="material-icons">close</span>
          </button>
        </div>
        <div className="p-4">
          <button 
            className="bg-[#4285F4] text-white w-full rounded-md py-2 px-4 flex items-center justify-center hover:bg-blue-600 transition duration-200 ease-in-out mb-4"
            onClick={() => {
              onNewLetter();
              onClose();
            }}
          >
            <span className="material-icons text-sm mr-1">add</span>
            New Letter
          </button>
          
          {isLoading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#4285F4]"></div>
            </div>
          ) : letters.length === 0 ? (
            <div className="text-center py-6 text-neutral-500">
              <span className="material-icons text-4xl mb-2">description</span>
              <p>No letters yet</p>
              <p className="text-sm">Create your first letter to get started</p>
            </div>
          ) : (
            letters.map((letter) => (
              <div 
                key={letter.id}
                className="py-2 px-3 rounded-md hover:bg-neutral-100 cursor-pointer mb-1"
                onClick={() => handleLetterSelect(letter.id)}
              >
                <h3 className="font-medium text-sm text-neutral-800">{letter.title}</h3>
                <p className="text-xs text-neutral-500">Last edited: {formatDate(letter.updatedAt)}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
