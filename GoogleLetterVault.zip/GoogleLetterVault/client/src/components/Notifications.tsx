import React, { useState, useEffect } from "react";
import { useLetters } from "@/context/LetterContext";

export default function Notifications() {
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const { currentLetter } = useLetters();

  // Implement your notification logic here
  // For example, when a letter is saved to Drive, show the success notification

  // This will be triggered by context events

  return (
    <>
      {/* Success Notification */}
      {showSuccess && (
        <div className="fixed bottom-4 right-4 bg-[#34A853] text-white px-4 py-3 rounded-md shadow-lg flex items-center">
          <span className="material-icons mr-2">check_circle</span>
          <span>Letter saved to Google Drive</span>
        </div>
      )}
      
      {/* Error Notification */}
      {showError && (
        <div className="fixed bottom-4 right-4 bg-[#EA4335] text-white px-4 py-3 rounded-md shadow-lg flex items-center">
          <span className="material-icons mr-2">error</span>
          <span>{errorMessage || "An error occurred"}</span>
        </div>
      )}
    </>
  );
}
