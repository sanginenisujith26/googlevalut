import React from "react";
import { editorCommands } from "@/lib/editor";
import { useLetters } from "@/context/LetterContext";

interface EditorToolbarProps {
  title: string;
  setTitle: (title: string) => void;
  onSave: () => Promise<void>;
  lastSaved: string | null;
  editorRef: React.RefObject<HTMLDivElement>;
}

export default function EditorToolbar({ 
  title, 
  setTitle, 
  onSave, 
  lastSaved,
  editorRef 
}: EditorToolbarProps) {
  const { isSaving } = useLetters();

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  return (
    <div className="border-b border-neutral-200 p-2 flex items-center flex-wrap">
      <input
        type="text"
        placeholder="Letter Title"
        className="text-lg font-medium px-2 py-1 mr-4 rounded border-0 focus:ring-0 focus:outline-none"
        value={title}
        onChange={handleTitleChange}
      />
      
      <div className="flex items-center space-x-1 mr-4">
        {editorCommands.slice(0, 3).map((command) => (
          <button
            key={command.name}
            className="p-1.5 rounded hover:bg-neutral-100"
            title={command.name.charAt(0).toUpperCase() + command.name.slice(1)}
            onClick={() => {
              editorRef.current?.focus();
              command.execute();
            }}
          >
            <span className="material-icons text-neutral-700">{command.icon}</span>
          </button>
        ))}
      </div>
      
      <div className="flex items-center space-x-1 mr-4">
        {editorCommands.slice(3, 7).map((command) => (
          <button
            key={command.name}
            className="p-1.5 rounded hover:bg-neutral-100"
            title={command.name.charAt(0).toUpperCase() + command.name.slice(1)}
            onClick={() => {
              editorRef.current?.focus();
              command.execute();
            }}
          >
            <span className="material-icons text-neutral-700">{command.icon}</span>
          </button>
        ))}
      </div>
      
      <div className="flex items-center space-x-1 mr-4">
        {editorCommands.slice(7, 9).map((command) => (
          <button
            key={command.name}
            className="p-1.5 rounded hover:bg-neutral-100"
            title={command.name.charAt(0).toUpperCase() + command.name.slice(1)}
            onClick={() => {
              editorRef.current?.focus();
              command.execute();
            }}
          >
            <span className="material-icons text-neutral-700">{command.icon}</span>
          </button>
        ))}
      </div>
      
      <div className="ml-auto flex items-center">
        {lastSaved && <span className="text-sm text-neutral-500 mr-2">Last saved: {lastSaved}</span>}
        <button
          className="bg-[#4285F4] text-white px-4 py-1.5 rounded-md flex items-center hover:bg-blue-600 transition duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={onSave}
          disabled={isSaving}
        >
          <span className="material-icons text-sm mr-1">save</span>
          Save
        </button>
      </div>
    </div>
  );
}
