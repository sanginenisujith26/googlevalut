import React from "react";
import { useLetters } from "@/context/LetterContext";
import { useAuth } from "@/context/AuthContext";

export default function LoadingOverlay() {
  const { isSaving } = useLetters();
  const { isLoading: isAuthLoading } = useAuth();
  
  if (!isSaving && !isAuthLoading) return null;
  
  let message = "Loading...";
  if (isSaving) {
    message = "Saving your letter...";
  } else if (isAuthLoading) {
    message = "Authenticating...";
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl flex flex-col items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#4285F4] mb-4"></div>
        <p className="text-neutral-800">{message}</p>
      </div>
    </div>
  );
}
