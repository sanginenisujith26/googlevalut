import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useLetters } from "@/context/LetterContext";

export default function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const { currentLetter, saveToDrive, isSaving } = useLetters();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const toggleUserMenu = () => {
    setShowUserMenu(!showUserMenu);
  };

  const handleLogout = async () => {
    await logout();
  };

  const handleClickOutside = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (!target.closest("#userMenuContainer")) {
      setShowUserMenu(false);
    }
  };

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <svg className="w-8 h-8 mr-2 text-[#4285F4]" fill="currentColor" viewBox="0 0 24 24">
            <path d="M21.17,2.06A13.1,13.1,0,0,0,19,1.87a12.94,12.94,0,0,0-7,2.05,12.94,12.94,0,0,0-7-2,13.1,13.1,0,0,0-2.17.19A1,1,0,0,0,2,3.17V21a1,1,0,0,0,1.08,1,10.9,10.9,0,0,1,1.88-.17,11.07,11.07,0,0,1,7,2.33,11.18,11.18,0,0,1,7-2.33,10.9,10.9,0,0,1,1.88.17A1,1,0,0,0,22,21V3.17A1,1,0,0,0,21.17,2.06ZM20,19.6a9.08,9.08,0,0,0-8,2.19V5.88A10.93,10.93,0,0,1,18.53,4,9.44,9.44,0,0,1,20,4.09Z" />
          </svg>
          <h1 className="text-xl font-poppins font-semibold text-neutral-800">LetterDrive</h1>
        </div>
        
        {isAuthenticated ? (
          <div className="flex items-center">
            <button 
              className="mr-4 bg-[#4285F4] text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-600 transition duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => saveToDrive()}
              disabled={isSaving || !currentLetter}
            >
              <span className="material-icons text-sm mr-1">save</span>
              Save to Drive
            </button>
            
            <div className="relative" id="userMenuContainer">
              <button 
                className="flex items-center focus:outline-none"
                onClick={toggleUserMenu}
              >
                <img 
                  src={user?.photoUrl || "https://ui-avatars.com/api/?name=User&background=random"} 
                  alt="User profile" 
                  className="w-9 h-9 rounded-full border-2 border-neutral-200"
                />
                <span className="material-icons text-neutral-600 ml-1">arrow_drop_down</span>
              </button>
              
              {showUserMenu && (
                <div 
                  className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-4 py-2 border-b border-neutral-200">
                    <p className="text-sm font-medium text-neutral-800">{user?.displayName}</p>
                    <p className="text-xs text-neutral-600">{user?.email}</p>
                  </div>
                  <button 
                    className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
                    onClick={handleLogout}
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div>
            <div id="googleSignInButton"></div>
          </div>
        )}
      </div>
    </header>
  );
}
