import React, { useState, useEffect } from "react";
import { useLetters } from "@/context/LetterContext";
import { formatDistanceToNow } from "date-fns";

interface SidebarProps {
  onNewLetter: () => Promise<void>;
}

export default function Sidebar({ onNewLetter }: SidebarProps) {
  const { letters, currentLetter, fetchLetter, isLoading } = useLetters();
  const [activeFolder, setActiveFolder] = useState<string>("all");

  const handleLetterSelect = async (id: number) => {
    await fetchLetter(id);
  };

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (e) {
      return "Unknown date";
    }
  };

  return (
    <div className="w-full md:w-64 bg-white border-r border-neutral-200 md:flex flex-col hidden">
      <div className="p-4 border-b border-neutral-200">
        <button 
          className="bg-[#4285F4] text-white w-full rounded-md py-2 px-4 flex items-center justify-center hover:bg-blue-600 transition duration-200 ease-in-out"
          onClick={onNewLetter}
        >
          <span className="material-icons text-sm mr-1">add</span>
          New Letter
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h2 className="text-sm font-medium text-neutral-700 mb-2">My Letters</h2>
          
          {isLoading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#4285F4]"></div>
            </div>
          ) : letters.length === 0 ? (
            <div className="text-center py-6 text-neutral-500">
              <span className="material-icons text-4xl mb-2">description</span>
              <p>No letters yet</p>
              <p className="text-sm">Create your first letter to get started</p>
            </div>
          ) : (
            letters.map((letter) => (
              <div 
                key={letter.id}
                className={`py-2 px-3 rounded-md hover:bg-neutral-100 cursor-pointer mb-1 group ${
                  currentLetter?.id === letter.id ? "bg-neutral-100" : ""
                }`}
                onClick={() => handleLetterSelect(letter.id)}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium text-sm text-neutral-800">{letter.title}</h3>
                    <p className="text-xs text-neutral-500">Last edited: {formatDate(letter.updatedAt)}</p>
                  </div>
                  <div className="hidden group-hover:block">
                    <button className="text-neutral-500 hover:text-neutral-700">
                      <span className="material-icons text-lg">more_vert</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
