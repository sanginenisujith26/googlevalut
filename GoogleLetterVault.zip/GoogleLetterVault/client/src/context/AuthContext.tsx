import React, { createContext, useContext, useState, useEffect } from "react";
import { useLocation } from "wouter";
import { getCurrentUser, logout as authLogout } from "@/lib/auth";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => Promise<void>;
  checkAuth: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const login = (userData: User) => {
    setUser(userData);
  };

  const logout = async () => {
    try {
      await authLogout();
      setUser(null);
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was a problem logging out.",
        variant: "destructive",
      });
    }
  };

  const checkAuth = async (): Promise<boolean> => {
    setIsLoading(true);
    try {
      const userData = await getCurrentUser();
      if (userData) {
        setUser(userData);
        setIsLoading(false);
        return true;
      }
      setUser(null);
      setIsLoading(false);
      return false;
    } catch (error) {
      setUser(null);
      setIsLoading(false);
      return false;
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        checkAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
