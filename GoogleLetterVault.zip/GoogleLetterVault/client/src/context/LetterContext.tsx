import React, { createContext, useContext, useState, useEffect } from "react";
import { Letter } from "@shared/schema";
import { getLetters, getLetter, createNewLetter, updateLetter, saveLetterToDrive } from "@/lib/drive";
import { useAuth } from "./AuthContext";
import { useToast } from "@/hooks/use-toast";

interface LetterContextType {
  letters: Letter[];
  currentLetter: Letter | null;
  setCurrentLetter: (letter: Letter | null) => void;
  fetchLetters: () => Promise<void>;
  fetchLetter: (id: number) => Promise<Letter | null>;
  createLetter: (title: string, content: string) => Promise<Letter | null>;
  saveLetter: (title: string, content: string) => Promise<Letter | null>;
  saveToDrive: () => Promise<Letter | null>;
  isLoading: boolean;
  setSaving: (isSaving: boolean) => void;
  isSaving: boolean;
}

const LetterContext = createContext<LetterContextType | undefined>(undefined);

export function LetterProvider({ children }: { children: React.ReactNode }) {
  const [letters, setLetters] = useState<Letter[]>([]);
  const [currentLetter, setCurrentLetter] = useState<Letter | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSaving, setSaving] = useState<boolean>(false);
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const fetchLetters = async () => {
    if (!isAuthenticated) return;
    
    setIsLoading(true);
    try {
      const fetchedLetters = await getLetters();
      setLetters(fetchedLetters);
    } catch (error) {
      toast({
        title: "Failed to load letters",
        description: "There was a problem loading your letters.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchLetter = async (id: number): Promise<Letter | null> => {
    if (!isAuthenticated) return null;
    
    setIsLoading(true);
    try {
      const letter = await getLetter(id);
      setCurrentLetter(letter);
      return letter;
    } catch (error) {
      toast({
        title: "Failed to load letter",
        description: "There was a problem loading your letter.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const createLetter = async (title: string, content: string): Promise<Letter | null> => {
    if (!isAuthenticated) return null;
    
    setSaving(true);
    try {
      const newLetter = await createNewLetter(title, content);
      setLetters(prev => [...prev, newLetter]);
      setCurrentLetter(newLetter);
      toast({
        title: "Letter created",
        description: "Your letter has been created successfully.",
      });
      return newLetter;
    } catch (error) {
      toast({
        title: "Failed to create letter",
        description: "There was a problem creating your letter.",
        variant: "destructive",
      });
      return null;
    } finally {
      setSaving(false);
    }
  };

  const saveLetter = async (title: string, content: string): Promise<Letter | null> => {
    if (!isAuthenticated || !currentLetter) return null;
    
    setSaving(true);
    try {
      const updatedLetter = await updateLetter(currentLetter.id, title, content);
      setLetters(prev => prev.map(letter => 
        letter.id === updatedLetter.id ? updatedLetter : letter
      ));
      setCurrentLetter(updatedLetter);
      toast({
        title: "Letter saved",
        description: "Your letter has been saved successfully.",
      });
      return updatedLetter;
    } catch (error) {
      toast({
        title: "Failed to save letter",
        description: "There was a problem saving your letter.",
        variant: "destructive",
      });
      return null;
    } finally {
      setSaving(false);
    }
  };

  const saveToDrive = async (): Promise<Letter | null> => {
    if (!isAuthenticated || !currentLetter) return null;
    
    setSaving(true);
    try {
      const updatedLetter = await saveLetterToDrive(currentLetter);
      setLetters(prev => prev.map(letter => 
        letter.id === updatedLetter.id ? updatedLetter : letter
      ));
      setCurrentLetter(updatedLetter);
      toast({
        title: "Saved to Google Drive",
        description: "Your letter has been saved to Google Drive.",
      });
      return updatedLetter;
    } catch (error) {
      toast({
        title: "Failed to save to Google Drive",
        description: "There was a problem saving your letter to Google Drive.",
        variant: "destructive",
      });
      return null;
    } finally {
      setSaving(false);
    }
  };



  useEffect(() => {
    if (isAuthenticated) {
      fetchLetters();
    }
  }, [isAuthenticated]);

  return (
    <LetterContext.Provider
      value={{
        letters,
        currentLetter,
        setCurrentLetter,
        fetchLetters,
        fetchLetter,
        createLetter,
        saveLetter,
        saveToDrive,
        isLoading,
        isSaving,
        setSaving
      }}
    >
      {children}
    </LetterContext.Provider>
  );
}

export function useLetters() {
  const context = useContext(LetterContext);
  if (context === undefined) {
    throw new Error("useLetters must be used within a LetterProvider");
  }
  return context;
}
