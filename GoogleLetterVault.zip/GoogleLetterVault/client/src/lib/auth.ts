import { apiRequest } from "./queryClient";
import { User } from "@shared/schema";

interface GoogleAuthResponse {
  credential: string;
}

export const initGoogleAuth = (callback: (response: GoogleAuthResponse) => void) => {
  console.log("VITE_GOOGLE_CLIENT_ID:", import.meta.env.VITE_GOOGLE_CLIENT_ID);
  if (window.google) {
    window.google.accounts.id.initialize({
      client_id: import.meta.env.VITE_GOOGLE_CLIENT_ID || "",
      callback,
      // Remove scope as it's not needed for basic sign-in (One Tap)
      // The scopes will be requested separately for Drive access
    });

    window.google.accounts.id.renderButton(
      document.getElementById("googleSignInButton")!,
      { 
        theme: "outline", 
        size: "large",
        width: 300,
        type: "standard",
        text: "signin_with",
        logo_alignment: "center"
      }
    );
    
    console.log("Google Sign-In button rendered");
  } else {
    console.error("Google auth SDK not loaded");
  }
};

export const logout = async (): Promise<void> => {
  try {
    await apiRequest("POST", "/api/auth/logout", undefined);
    window.location.href = "/";
  } catch (error) {
    console.error("Logout failed:", error);
    throw error;
  }
};

export const getCurrentUser = async (): Promise<User | null> => {
  try {
    const response = await fetch("/api/auth/user", {
      credentials: "include",
    });

    if (response.status === 401) {
      return null;
    }

    if (!response.ok) {
      throw new Error(`Failed to get current user: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Failed to get current user:", error);
    return null;
  }
};

// Add type declaration for google auth
declare global {
  interface Window {
    google: {
      accounts: {
        id: {
          initialize: (config: any) => void;
          renderButton: (element: HTMLElement, options: any) => void;
          prompt: () => void;
        };
      };
    };
  }
}
