import { apiRequest } from "./queryClient";
import { Letter } from "@shared/schema";

export const saveLetterToDrive = async (letter: Letter): Promise<Letter> => {
  try {
    const response = await apiRequest(
      "POST",
      "/api/drive/save",
      { letterId: letter.id }
    );

    return await response.json();
  } catch (error) {
    console.error("Failed to save letter to Google Drive:", error);
    throw error;
  }
};

export const createNewLetter = async (title: string, content: string): Promise<Letter> => {
  try {
    const response = await apiRequest(
      "POST",
      "/api/letters",
      { title, content }
    );

    return await response.json();
  } catch (error) {
    console.error("Failed to create new letter:", error);
    throw error;
  }
};

export const updateLetter = async (letterId: number, title: string, content: string): Promise<Letter> => {
  try {
    const response = await apiRequest(
      "PATCH",
      `/api/letters/${letterId}`,
      { title, content }
    );

    return await response.json();
  } catch (error) {
    console.error("Failed to update letter:", error);
    throw error;
  }
};

export const getLetters = async (): Promise<Letter[]> => {
  try {
    const response = await fetch("/api/letters", {
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Failed to get letters: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Failed to get letters:", error);
    throw error;
  }
};

export const getLetter = async (id: number): Promise<Letter> => {
  try {
    const response = await fetch(`/api/letters/${id}`, {
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(`Failed to get letter: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`Failed to get letter ${id}:`, error);
    throw error;
  }
};
