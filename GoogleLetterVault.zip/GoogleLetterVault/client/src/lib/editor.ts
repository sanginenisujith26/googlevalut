export interface EditorCommand {
  name: string;
  icon: string;
  execute: () => void;
}

const formatText = (command: string, value: string | null = null) => {
  document.execCommand(command, false, value);
};

export const editorCommands: EditorCommand[] = [
  {
    name: "bold",
    icon: "format_bold",
    execute: () => formatText("bold")
  },
  {
    name: "italic",
    icon: "format_italic",
    execute: () => formatText("italic")
  },
  {
    name: "underline",
    icon: "format_underlined",
    execute: () => formatText("underline")
  },
  {
    name: "alignLeft",
    icon: "format_align_left",
    execute: () => formatText("justifyLeft")
  },
  {
    name: "alignCenter",
    icon: "format_align_center",
    execute: () => formatText("justifyCenter")
  },
  {
    name: "alignRight",
    icon: "format_align_right",
    execute: () => formatText("justifyRight")
  },
  {
    name: "justify",
    icon: "format_align_justify",
    execute: () => formatText("justifyFull")
  },
  {
    name: "bulletList",
    icon: "format_list_bulleted",
    execute: () => formatText("insertUnorderedList")
  },
  {
    name: "numberedList",
    icon: "format_list_numbered",
    execute: () => formatText("insertOrderedList")
  }
];

export const getContentFromEditor = (editorRef: React.RefObject<HTMLDivElement>): string => {
  if (!editorRef.current) return "";
  return editorRef.current.innerHTML;
};

export const setContentInEditor = (editorRef: React.RefObject<HTMLDivElement>, content: string): void => {
  if (editorRef.current) {
    editorRef.current.innerHTML = content;
  }
};
